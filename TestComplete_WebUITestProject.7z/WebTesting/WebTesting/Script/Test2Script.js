﻿function Test2()
{
  while  (Sys.WaitBrowser("iexplore").Exists)
    Sys.WaitBrowser("iexplore").Close();
//Clicks the 'Start' object.
  Aliases.explorer.wndShell_TrayWnd.Start.Click(32, 24);
  //Launches the specified browser and opens the specified URL in it.
  Browsers.Item(btIExplorer).Run("about:blank");
  //Opens the specified URL in a running instance of the specified browser.
  Browsers.Item(btIExplorer).Navigate("http://ec2-34-250-139-60.eu-west-1.compute.amazonaws.com/");
  //Clicks the 'textboxFullName' object.
  Aliases.iexplore.pageHaveFunTesting.textboxFullName.Click(143, 17);
  //Sets the text 'Oprean Nicolae' in the 'textboxFullName' text editor.
  Aliases.iexplore.pageHaveFunTesting.textboxFullName.SetText("Oprean Nicolae");
  //Checks whether the 'value' property of the Aliases.iexplore.pageHaveFunTesting.textboxFullName object equals 'Oprean Nicolae'.
  aqObject.CheckProperty(Aliases.iexplore.pageHaveFunTesting.textboxFullName, "value", cmpEqual, "Oprean Nicolae");
  //Clicks the 'textboxCountry' object.
  Aliases.iexplore.pageHaveFunTesting.textboxCountry.Click(114, 16);
  //Sets the text 'Romania' in the 'textboxCountry' text editor.
  Aliases.iexplore.pageHaveFunTesting.textboxCountry.SetText("Romania");
  //Checks whether the 'Text' property of the Aliases.iexplore.pageHaveFunTesting.textboxCountry object equals 'Romania'.
  aqObject.CheckProperty(Aliases.iexplore.pageHaveFunTesting.textboxCountry, "Text", cmpEqual, "Romania");
  //Clicks the 'textboxYob' object.
  Aliases.iexplore.pageHaveFunTesting.form.textboxYob.Click(65, 26);
  //Sets the text '1982' in the 'textboxYob' text editor.
  Aliases.iexplore.pageHaveFunTesting.form.textboxYob.SetText("1982");
  //Checks whether the 'value' property of the Aliases.iexplore.pageHaveFunTesting.form.textboxYob object equals '1982'.
  aqObject.CheckProperty(Aliases.iexplore.pageHaveFunTesting.form.textboxYob, "value", cmpEqual, "1982");
  //Clicks the 'passwordboxPosition' object.
  Aliases.iexplore.pageHaveFunTesting.form.passwordboxPosition.Click(152, 15);
  //Sets the text 'QA Engineer' in the 'passwordboxPosition' text editor.
  Aliases.iexplore.pageHaveFunTesting.form.passwordboxPosition.SetText("QA Engineer");
  //Clicks the 'buttonSave' control.
  Aliases.iexplore.pageHaveFunTesting.form.buttonSave.ClickButton();
  //Checks whether the 'contentText' property of the Aliases.iexplore.pageHaveFunTesting.panelModalFade.panelModalDialog.panelModalBody object equals 'You added
  //John Doe
  //to the list of entities.'.
  aqObject.CheckProperty(Aliases.iexplore.pageHaveFunTesting.panelModalFade.panelModalDialog.panelModalBody, "contentText", cmpEqual, "You added\nJohn Doe\nto the list of entities.");
  //Checks whether the 'Enabled' property of the Aliases.iexplore.pageHaveFunTesting.panelModalFade.panelModalDialog.buttonBack object equals True.
  aqObject.CheckProperty(Aliases.iexplore.pageHaveFunTesting.panelModalFade.panelModalDialog.buttonBack, "Enabled", cmpEqual, true);
  //Checks whether the 'contentText' property of the Aliases.iexplore.pageHaveFunTesting.panelModalFade.panelModalDialog.buttonBack object equals 'Back'.
  aqObject.CheckProperty(Aliases.iexplore.pageHaveFunTesting.panelModalFade.panelModalDialog.buttonBack, "contentText", cmpEqual, "Back");
  //Clicks the 'buttonBack' control.
  Aliases.iexplore.pageHaveFunTesting.panelModalFade.buttonBack.ClickButton();
}